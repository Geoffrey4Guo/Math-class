'Creates a Main class to run the above Math class with objects'

def main():

    'Creates an object called doing_math from the Math class'

    doing_math = Math(num1, num2)

    'Calls the functions and print the corresponding answers of the operations'

    print("The sum is", doing_math.add())

    print("The difference is", doing_math.subtract())

    print("The product is", doing_math.multiply())

    print("The quotient is", doing_math.divide())
    


'using the special variable __name__ to run the main program'

if __name__ == "__main__":

    main()